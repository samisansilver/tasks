<img src="https://iliasteel.ir/wp-content/uploads/2022/12/Asset-10.svg" style="width: 100px">

<?php /**PATH C:\xampp\htdocs\jobs\resources\views/components/application-logo.blade.php ENDPATH**/ ?>